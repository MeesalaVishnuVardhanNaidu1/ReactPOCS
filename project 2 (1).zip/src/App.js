import './App.css';
import Home from './Home';
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom';
import Details from './Details';

function App() {
  return (
    // <Home />
    <Router>
      <Routes>
        <Route path="/Details" element={<Details/>} />
        <Route path="/" element={<Home/>} />
      </Routes>
    </Router>
  );
}

export default App;
