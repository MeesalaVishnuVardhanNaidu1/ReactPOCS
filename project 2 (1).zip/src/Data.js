export const data = [
  {   
      "id": 1,
      "slug": "john",
      "firstname": "john",
      "lastname": "Doe",
      "dateofbirth": "19/08/2000",
      "age":"22",
      "memberId": "M190785654",
      "effectivedate":"20/07/2022",
      "status": "Active",
      "sex": "Male",
      "eachCard":
        {
      "Member Details": {
          "college": "Vel Tech",
          "state": "Andhra Pradesh",
          "country": "India",
          "DateOfJoin":"20 may 2021",
          "Course":"ECE",
          "Current":"second year"
        },
        "Physician Details": {
            "attributedPcp": "JohnDoe",
            "attributesPcpasof": "21may",
            "npi": 18253864,
            "LastPcpVisitedDate":"10march",
            "UpcomingVisiteDate":"15may",
            "upcomingDate": "12may21"
        },
      "Utilization Details": {
        "edVisits": 3,
        "preventableEdvisits": 3,
        "inpatientAdmits": 5,
        "pcpVisits": 0,
        "specialistVisit": 3
      },
      "Cost Details": {
        "medicalSpends": 15000,
        "totalSpends": 20000,
        "totalPharmaciesspend": 5000
      }
    },
    "notifications":[
      {
        "Care Management":
        [
        "Disease Management System",
        "Transition Of Care Program",
        "Care Coordination Program"
        ]
      },
      {
        "Clinical Quality & Outcomes":
        [
         "someDisease",
         "someotherDisease"
        ]
      },
      {
        "Emergency Department Utilization":
        [
          "someDisease",
          "someotherDisease"
        ]
      },
      {
        "Inpatient Utilization":
        [
        "someDisease",
        "someotherDisease"
        ]
      }
    ]
    
  },
  {   
    "id": 2,
    "slug": "Kalyan",
    "firstname": "Kalyan",
    "lastname": "Krishna",
    "dateofbirth": "27/03/1971",
    "memberId": "M190785655",
    "effectivedate":"27 march 2022",
    "age":"52",
    "status": "Active",
    "sex": "Male",
    "eachCard":{
    "Member Details": {
      "college": "Vel Tech",
      "state": "Andhra Pradesh",
      "country": "India",
      "DateOfJoin":"20 may 2021",
    "Course":"ECE",
    "Current":"second year"
      },
      "Physician Details": {
          "attributedPcp": "JohnDoe",
          "attributesPcpasof": "21may",
          "npi":1365384789,
          "LastPcpVisitedDate":"10march",
          "UpcomingVisiteDate":"15may",
          "upcomingDate": "12may21"
      },
    "Utilization Details": {
      "edVisits": 3,
      "preventableEdvisits": 3,
      "inpatientAdmits": 5,
      "pcpVisits": 0,
      "specialistVisit": 3
    },
    "Cost Details": {
      "medicalSpends": 15000,
      "totalSpends": 20000,
      "totalPharmaciesspend": 5000
    }
  },
  "notifications":[
    {
      "Care Management":
      [
      "Disease Management System",
      "Transition Of Care Program",
      "Care Coordination Program"
      ]
    },
    {
      "Clinical Quality & Outcomes":
      [
       "someDisease",
       "someotherDisease"
      ]
    },
    {
      "Emergency Department Utilization":
      [
        "someDisease",
        "someotherDisease"
      ]
    },
    {
      "Inpatient Utilization":
      [
      "someDisease",
      "someotherDisease"
      ]
    }
  ]
},
{   
      "id": 3,
      "slug": "Thirumala",
      "firstname": "Thirumala",
      "lastname": "Keshava",
      "dateofbirth": "29/09/1986",
      "memberId": "M190785656",
      "effectivedate":" 20 may 2022",
      "age":"36",
      "status": "Active",
      "sex": "Male",
      "eachCard":{
      "Member Details": {
        "college": "Vel Tech",
        "state": "Andhra Pradesh",
        "country": "India",
        "DateOfJoin":"20 may 2021",
      "Course":"ECE",
      "Current":"second year"
        },
        "Physician Details": {
            "attributedPcp": "Thirumala",
            "attributesPcpasof": "21may",
            "npi": 143865286,
            "LastPcpVisitedDate":"10march",
            "UpcomingVisiteDate":"15may",
            "upcomingDate": "12may21"
        },
      "Utilization Details": {
        "edVisits": 3,
        "preventableEdvisits": 3,
        "inpatientAdmits": 5,
        "pcpVisits": 0,
        "specialistVisit": 3
      },
      "Cost Details": {
        "medicalSpends": 15000,
        "totalSpends": 20000,
        "totalPharmaciesspend": 5000
      }
    },
    "notifications":[
      {
        "Care Management":
        [
        "Disease Management System",
        "Transition Of Care Program",
        "Care Coordination Program"
        ]
      },
      {
        "Clinical Quality & Outcomes":
        [
         "someDisease",
         "someotherDisease"
        ]
      },
      {
        "Emergency Department Utilization":
        [
          "someDisease",
          "someotherDisease"
        ]
      },
      {
        "Inpatient Utilization":
        [
        "someDisease",
        "someotherDisease"
        ]
      }
    ]
  },
  {   
    "id": 4,
    "slug": "Tony",
    "firstname": "Tony",
    "lastname": "Stark",
    "dateofbirth": "11/4/1976",
    "memberId": "M190785657",
    "effectivedate":"10 june 2022",
    "age":"47",
    "status": "Active",
    "sex": "Male",
    "eachCard":{
    "Member Details": {
      "college": "Vel Tech",
      "state": "Andhra Pradesh",
      "country": "India",
      "DateOfJoin":"20 may 2021",
    "Course":"ECE",
    "Current":"second year"
      },
      "Physician Details": {
          "attributedPcp": "JohnDoe",
          "attributesPcpasof": "21may",
          "npi": 19865367,
          "LastPcpVisitedDate":"10march",
          "UpcomingVisiteDate":"15may",
          "upcomingDate": "12may21"
      },
    "Utilization Details": {
      "edVisits": 3,
      "preventableEdvisits": 3,
      "inpatientAdmits": 5,
      "pcpVisits": 0,
      "specialistVisit": 3
    },
    "Cost Details": {
      "medicalSpends": 15000,
      "totalSpends": 20000,
      "totalPharmaciesspend": 5000
    }
  },
  "notifications":[
    {
      "Care Management":
      [
      "Disease Management System",
      "Transition Of Care Program",
      "Care Coordination Program"
      ]
    },
    {
      "Clinical Quality & Outcomes":
      [
       "someDisease",
       "someotherDisease"
      ]
    },
    {
      "Emergency Department Utilization":
      [
        "someDisease",
        "someotherDisease"
      ]
    },
    {
      "Inpatient Utilization":
      [
      "someDisease",
      "someotherDisease"
      ]
    }
  ]
}

]
