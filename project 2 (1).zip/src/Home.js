import React, { useState } from 'react'
import {useNavigate} from "react-router-dom";
import { data } from './Data.js';
import Button from '@mui/material/Button';
// import TextField from '@mui/material/TextField';
import {Table,TableHead,TableRow,TableCell,TableBody, Typography} from '@mui/material'
import {Grid,Paper} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import './HomeStyles.css';
import Stack from '@mui/material/Stack';


const Home = () => {
  const navigate=useNavigate();
  const [text, setText] = useState(data)
  const [searchQuery, setSearchQuery] = useState({
    firstName: "",
    lastName: "",
    dateofBirth: "",
    memberId: ""
  });
  // const inputStyle ={
  //   padding: '15px 0px 0px 10px',
  // }
  const btn={
    background:" 0% 0% no-repeat padding-box",
    border: "1px solid #23245E",
    borderRadius: "47px",
    opacity: 1,
  }
  const btn1={
 background:" #24245E 0% 0% no-repeat padding-box",
 border: "1px solid #23245E",
 borderRadius: "47px",
 opacity: 1,
  }
  const inputStyle ={
    margin:'9px 0px',
    padding:'5px',
    width:'100%',
    borderRadius: '47px',
    backgroundColor: '#e8eaf6',
    border:'0',
    outline:'0',
    color:'#3f51b5'
     }
     const inputStyle1 ={
      margin:'5px',
      padding:'9px',
      textAligh:'center',
     color:'#1946b5',
     fontweight: 'bolder',
  }


  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setSearchQuery((prevQuery) => ({ ...prevQuery, [name]: value }));
  };
  //  const detailLink=(item)=>{
  //   console.log(item);
  //   <Link to="/Details" state={item} />
  //  }
  const searchItem = () => {
    const filteredData = data.filter((item) => {
      if (searchQuery.firstName.toLowerCase()) {
        return item.firstname.toLowerCase().includes(searchQuery.firstName.toLowerCase())
      }else if (searchQuery.lastName.toLowerCase()) {
        return item.lastname.toLowerCase().includes(searchQuery.lastName.toLowerCase())
      } else if (searchQuery.dateofBirth) {
        return item.dateofbirth.toString().includes(searchQuery.dateofBirth.toLowerCase())
      } else
        return item.memberId.toString().includes(searchQuery.memberId.toString())
    });
    setText(filteredData)
  }

  const resetSearch = () => {
  setText(data);
  setSearchQuery({
    firstName: "",
    lastName: "",
    dateofBirth: "",
    memberId: ""
  });
  };

  const detailLink=(item)=>{
    console.log('item is', item)
    navigate('/Details',{state:{item}})
  }


  return (
    <Grid container spacing={2} >
      <Grid  item xs={3} className='inputSection'>
        <Paper style={{height:'100%',padding:'20px'}}>
        <Stack  style={ inputStyle1 } direction="row" gap={0}>
        <SearchIcon fontSize='large' style={{color:'#24245E' }}/>
        <Typography  style={{color:'#24245E' , font: "normal normal bold 20px/25px Helvetica Neue"}}>Person Details Search</Typography>
        </Stack >
        <form >
          <Typography className='titleHeader'>First Name</Typography>
          <input type="text" style={ inputStyle }   name='firstName'  value={searchQuery.firstName} onChange={handleInputChange} />
      <br />
      <Typography className='titleHeader'>Last Name</Typography>
      <input type="text" style={ inputStyle }   name='lastName'  value={searchQuery.lastName} onChange={handleInputChange} />
      <br />
      <Typography className='titleHeader'>Date Of Birth</Typography>
      <input  style={ inputStyle }   name='dateofBirth'  value={searchQuery.dateofBirth} onChange={handleInputChange} />
      <br />
      <Typography className='titleHeader'>Member ID</Typography>
      <input type="text" style={ inputStyle }   name='memberId'  value={searchQuery.memberId} onChange={handleInputChange} />
      <br />
          <Button onClick={resetSearch} sx={{ margin:'50px 0px 0px 35px' ,padding:"2px 15px 2px 15px"}}  variant="outlined" style={btn} >Reset</Button>
          <Button onClick={searchItem} sx={{ margin:'50px 0px 0px 35px' , padding:"2px 15px 2px 15px"}}  variant="contained" style={btn1} >search</Button>
      </form>
        </Paper>
      </Grid>
      <Grid item xs={9}>
        <Paper style={{height:"100%",padding:'20px',textAlign:"center"}}>
          <Table style={{width:"100%"}}>
            <TableHead>
              <TableRow  >
                <TableCell className='tableHeader'>First Name</TableCell>
                <TableCell className='tableHeader'>Last Name</TableCell>
                <TableCell className='tableHeader'>Date of Birth</TableCell>
                <TableCell className='tableHeader'>Member ID</TableCell>
              </TableRow>
            </TableHead>
  
            <TableBody>
              {text.map((item,index) => (
                 
                <TableRow key={index} onClick={()=>detailLink(item)}>
                  <TableCell className="searchBox">{item.firstname}</TableCell>
                  <TableCell className="searchBox">{item.lastname}</TableCell>
                  <TableCell className="searchBox">{item.dateofbirth}</TableCell>
                  <TableCell className="searchBox">{item.memberId}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Paper>
      </Grid>
    </Grid>
  )
}

export default Home
