import {
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Typography,
} from "@mui/material";
import React from "react";
import {useLocation } from "react-router-dom";
import { Grid } from "@mui/material";
// import Notifications from "./Notifications";
import CardData from "./CardData";
import './HomeStyles.css';
import SmallTab from "./SmallTab";




const Details = () => {
  
  const location = useLocation();
  const propsData = location.state.item;
  console.log('propsdata is',propsData)
  return (
    <div className="detailPage">
      <Grid container spacing={0}>
        <Grid item xs={4}>
          {/* <Paper style={{ padding: "20px" }}> */}
            <Typography
              variant="h4" fontWeight="bold" style={{"color":"#24245E" ,"padding":"40px"}}
            >
              {propsData.firstname + " " + propsData.lastname}
            </Typography>
          {/* </Paper> */}
        </Grid>
        <Grid item xs={8}>
          {/* <Paper style={{ padding: "0px" }}> */}
            <Table >
              <TableHead>
                <TableRow >
                  <TableCell className="detailTable">Effective Date</TableCell>
                  <TableCell className="detailTable">Status</TableCell>
                  <TableCell className="detailTable">Age</TableCell>
                  <TableCell className="detailTable">DOB</TableCell>
                  <TableCell className="detailTable">Sex</TableCell>
                  <TableCell className="detailTable">ID</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                <TableRow>
                  <TableCell>{propsData.effectivedate}</TableCell>
                  <TableCell>{propsData.status}</TableCell>
                  <TableCell>{propsData.age}</TableCell>
                  <TableCell>{propsData.dateofbirth}</TableCell>
                  <TableCell>{propsData.sex}</TableCell>
                  <TableCell>{propsData.memberId}</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          {/* </Paper> */}
        </Grid>
      </Grid>
      <br/>
     <CardData propData={propsData} key={propsData.id}/>
     <SmallTab noti={propsData}/>
   {/* <Notifications noti={propsData} /> */}
    </div>
  );
};

export default Details;
