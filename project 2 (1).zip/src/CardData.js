import React from 'react'
//import cardsData from './data/cardsData.json'
import CardsDetails from './Card'
import { Grid } from '@mui/material'


const CardData = (props) => {
  const obj=props.propData.eachCard;
  return (
    <div>
     <Grid container spacing={4}>
      {Object.keys(obj).map(objKey => {
        return (
        <CardsDetails data={obj[objKey]} title={objKey} key={objKey}/>
      )})}
      </Grid> 
    </div>
  )
}

export default CardData;