import * as React from 'react';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
// import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
// import Button from '@mui/material/Button';
// import Typography from '@mui/material/Typography';
import {Grid} from '@mui/material';
// import PermIdentityIcon from '@mui/icons-material/PermIdentity';
import './HomeStyles.css'



export default function CardsDetails(props) {
  const {data,title}=props
// const propData = props.propData;
  return (
    
      <Grid item xs={3} className='cards'>
        <Box sx={{ minHeight: 275}}  className="cardsContent">
      <Card>
       <React.Fragment>
    <CardContent>
        <h3 sx={{ fontSize: 18 }} className='cardTitle' >
          {/* < PermIdentityIcon fontSize='large' /> */}
          {title}<hr  className='hr-line'/>
      </h3>
      
      <Grid container spacing={4} >
     {Object.keys(data).map((objectKey) => (
     <Grid item xs={6}>
          <label className='cardLabel'>{objectKey}</label> <br />
          <span className='labelValue'>
            {data[objectKey]}
          </span>
        </Grid>
        ))}
      </Grid>
      </CardContent>
     </React.Fragment>
     </Card>
    </Box>
  {/* //       <Box sx={{ minWidth: 275 }}>
  //     <Card>
  //      <React.Fragment>
  //   <CardContent>
  //     <Typography sx={{ fontSize: 18 }} >< PermIdentityIcon fontSize='large' />
  //       Member Details
  //     </Typography><hr />
  //     <Grid container spacing={4} >
  //       <Grid item xs={6}  >
  //       <Typography color="secondary" >
  //       College
  //     </Typography>
  //     <Typography >
  //      {propData.memberDetails.college} 
  //     </Typography>
  //       </Grid>
  //       <Grid item xs={6}>
  //       <Typography color="secondary" >
  //       Date Of Join
  //     </Typography>
  //     <Typography >
  //      {propData.memberDetails.DateOfJoin} 
  //     </Typography>
  //       </Grid>
  //       <Grid item xs={6}>
  //       <Typography color="secondary" >
  //       State
  //     </Typography>
  //     <Typography >
  //      {propData.memberDetails.state} 
  //     </Typography>
  //       </Grid>
  //       <Grid item xs={6}>
  //       <Typography color="secondary" >
  //       Course
  //     </Typography>
  //     <Typography >
  //      {propData.memberDetails.Course} 
  //     </Typography>
  //       </Grid>
  //       <Grid item xs={6}>
  //       <Typography color="secondary" >
  //       Current
  //     </Typography>
  //     <Typography >
  //      {propData.memberDetails.Current} 
  //     </Typography>
  //       </Grid>
  //       <Grid item xs={6}>
  //       <Typography color="secondary" >
  //       Country
  //     </Typography>
  //     <Typography >
  //      {propData.memberDetails.country} 
  //     </Typography>
  //       </Grid>
       
  //     </Grid>
  //   </CardContent>
  // </React.Fragment>
  // </Card>
  //   </Box> */}
        
     </Grid>
   
  );
}