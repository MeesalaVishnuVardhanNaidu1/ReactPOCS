import React, { useState } from "react";
import { Grid, Typography } from "@mui/material";
import CardContent from "@mui/material/CardContent";
import Card from "@mui/material/Card";
import Box from "@mui/material/Box";
import "./Notification.css";
// import Checkbox from '@mui/material/Checkbox';

const SmallTab = (props) => {
  const obj = props.noti.notifications;
  let [currentNoti,setCurrentNoti] = useState(0);
  let [currentStatement,setCurrentStatement] = useState('Disease Management System');
  let [checked,setChecked]=useState(false);
  //let [commentVisible,setCommentVisible] = useState(false);
  let checkedCount=0;
  
 
  // const CheckboxWithComment () {
  //   const [selectedCheckbox,setSelectedCheckbox]=useState(null);
  //   const [commentVisible, setCommentVisible]= useState(false);
  // }
  const handleChange=(e)=>{
    const {value,checked}=e.target;
    console.log(checkedCount,"count")
    if(checked){
      // checkedCount++;
      setCurrentStatement(value);
      //setCommentVisible(false);
      setChecked(!checked);
      console.log(checkedCount,"countinloop")

    }
    // else{
    //   //setCommentVisible(true);
    //   setCurrentStatement("Please Select one checkbox")
    // }
    
    console.log(checkedCount,"countafter")
    
  }
  const typographyStyle = {
    textAlign: "center",
    color: "#24245E",
    font: "normal normal bold 20px/25px Helvetica Neue",
    padding: "5px",
  };
  return (
    <Grid container spacing={2}>
      <Grid item xs={9}>
        <Box sx={{ minWidth: 275 }}>
          <Card>
            <React.Fragment>
              <CardContent>
                <Typography
                  style={{
                    padding: "10px",
                    color: "#24245E",
                    "font-weight": "bold",
                    fontSize: "20px",
                  }}
                >
                  Notifications
                  {obj.map((objKey,index) => {
                    return (
                      <div className="dropdown">
                        <div
                          className="dropdown-btn"
                          onClick={(e) => {
                            setCurrentNoti(index)
                          }}
                        >
                          <label className="dropdownTitle">{Object.keys(objKey)[0]}</label>
                        </div>
                        {currentNoti === index && (
                          <div className="dropdown-content">
                            {obj[index][Object.keys(objKey)[0]].map((objectKey, index) => {
                              
                              checked=index===0? true : false
                               return (
                                <div className="dropdown-item">
                               <input type="checkbox" defaultChecked={checked} value={objectKey} onChange={handleChange} />
                              {" "} <label>Member has care team and enrolled in the {objectKey}</label>
                               <br/>
                               </div>
                               );
                              })}

                          </div>
                        )}
                      </div>
                    );
                  })}
                </Typography>
              </CardContent>
            </React.Fragment>
          </Card>
        </Box>
      </Grid>
      
      <Grid item xs={3}>
        <Box sx={{ minWidth: 275 }}>
          <Card>
            <React.Fragment>
              <CardContent>
                <Typography style={typographyStyle}>Details</Typography>
                <Grid >
                  <Grid className="detailBox">
                  <label className="cardLabel">status</label> <br />
                  <span className="labelValue">
                    Open
                  </span><br />
                  </Grid>
                 <Grid className="detailBox">
                 <label className="cardLabel">{Object.keys(obj[currentNoti])[0]}</label>{" "}
                  <br />
                  <span className="labelValue">{currentStatement}</span> <br />
                 </Grid>
                  <Grid className="detailBox">
                  <label className="cardLabel">Care Team</label> <br />
                  <span className="labelValue">Yes
                  </span>
                  
                  </Grid>
                </Grid>
              </CardContent>
            </React.Fragment>
          </Card>
        </Box>
      </Grid>
    </Grid>
    ) 
};

export default SmallTab;
