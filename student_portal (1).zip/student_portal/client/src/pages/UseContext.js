// import { createContext } from "react";
// export const UserContext = createContext();

// import { useHistory } from "react-router-dom";
// const ContactButton = () =>{
//      const history = useHistory(); 
//      const handleClick = () => { 
//          history.push("/contact");
//          }
//           return ( 
//              <button type="button" onClick={handleClick}>   Contact Us  </button>
//               );
// }




// export default ContactButton;