import React, { useContext } from "react";
import { UserContext } from "./UseContext";


const Context = () => {
  const user = useContext(UserContext);
  return(
    <div>
    <h1>{user}</h1>
  </div>
  )

};

export default Context;
