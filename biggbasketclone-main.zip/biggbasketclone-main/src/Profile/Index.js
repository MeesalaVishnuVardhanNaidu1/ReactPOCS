import React from 'react'

const Index = () => {
    return (
       <div style={{position:"absolute",width:"100%",height:"100vh",overflow:"hidden",backgroundColor:"red"}}>

      </div>
    )
}

export default Index