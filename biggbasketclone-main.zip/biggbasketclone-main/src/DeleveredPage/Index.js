import React from 'react'
const Index = () => {
  return (
    <div className='text-center h1 display-1'>successfully ordered your products
    </div>
    
  )
}
export default Index