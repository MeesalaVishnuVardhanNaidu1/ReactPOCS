import React from 'react'

const Footer = () => {
  return (
    
        <footer className="bg-light text-center text-lg-start mt-5">
        <div className="text-center p-3 ">
            © 2020 Copyright:
            <a className="text-dark" target="_blanck" href="https://BigBasket.com/">WWW.BigBasket.com</a>
        </div>
        </footer>
  )
}
export default Footer