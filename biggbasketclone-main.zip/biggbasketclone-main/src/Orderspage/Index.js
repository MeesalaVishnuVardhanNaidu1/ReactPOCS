import React from 'react'
import Orders from '../Components/OrdersItemCard/Index'
import axios from 'axios'
const Index = () => {
  return (
    <div>
      <Orders />
    </div>
  )
}

export default Index