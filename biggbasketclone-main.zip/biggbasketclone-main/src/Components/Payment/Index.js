import CheckoutForm from './CheckoutForm';
export default function App() {


  return (
    // <Elements stripe={stripePromise} options={options}>
      <CheckoutForm />
    // </Elements>
  );
};