import React from 'react'
import './index.css'

const Index = () => {
  return (
    <div className='loader'>
      
    </div>
  )
}

export default Index